# # 导入os模块
import os
import time
import requests
import json
# # 定义输入文件路径（其中r是转义字符，为了让 \ 不起作用）
# path_in = r'C:\Users\Administrator\Desktop\wk.mp4'
# # 定义输出文件路径
# path_out = r'C:\Users\Administrator\Desktop\wk.mp3'
# now = time.strftime("%Y-%m-%d-%H_%M_%S",time.localtime(time.time()))
# path = 'http://pili-live-hdl.miaobolive.com/live/4dca2c8c4e1191c4285055e1cf752e59.flv'
# # 拼接cmd下的命令
# cmd = "C:/Users/15256/Downloads/2021-10-26-00-34-45-www.gyan.dev-ffmpeg-4.4.1-full_build-shared/ffmpeg-4.4.1-full_build-shared/bin/ffmpeg.exe -i %s -t 10 -f wav -ar 16000 %s.wav"%(path,now)
# # 执行cmd命令
# os.system(cmd)
# a = "去你妈的这条妈的他妈的有趣他弟弟的有的"
# b = '无趣'
# if  b in a:
#     print(b,a)
#     print('无趣')

# 定义一个拿出敏感词库的函数
# def read_txt(file):
#     with open(file ,encoding='utf-8') as f:
#         data = f.read()
#         list_data = data.split('\n')
#         return list_data

# for word in read_txt('./targetword/target.txt'):
#     print(word)
# import time

# send_data = {
#                 'taskId':2,
#                 'companyId':2,
#                 'imgUrl':'targets',
#                 'createTime':time.strftime("%Y-%m-%d-%H:%M:%S",time.localtime(time.time()))
                
#             }
#                 # 发送相关参数
# response = requests.post('http://10.0.0.98:8088/wx/photo/saveVoidWarning', data=send_data)  
# a = '123'
# print(len(a))

content = '1234sadf,'

if len(content) != 0:
    """调用java接口"""
    send_data = {
        'taskId':1,
        'companyId':2,
        'imgUrl':'target',
        'content':content[:-1:]
        
    }
    send_data = json.dumps(send_data)
    # 发送相关参数
    response = requests.post('http://10.0.0.98:8088/wx/photo/saveVoidWarning', headers={'Content-Type':'application/json'},data=send_data)
    # return json.dumps(200,ensure_ascii=False)
