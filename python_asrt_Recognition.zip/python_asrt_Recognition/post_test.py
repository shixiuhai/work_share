"""Perform test request"""
import pprint
import json
import requests
import argparse
import io
## 定义访问接口
interfaceurl = "http://10.8.0.37:5100/gttx/objectrecognition"
# C:/Users/15256/Desktop/nowtime/yolov_smoke_v1.0/yolov5/smokingdata/images/train/000001.jpg
## 将要传入的数据设置为json格式
# http://pili-live-hdl.miaobolive.com/live/dfbe2bcc0acd956bda5c9a3d133e5c18.flv
# information = { 'path' : r'C:\Users\15256\Desktop\nowtime\吸烟视频\2.mp4',  
#                 'savePath' :'targetimages'} 
information = { 'path' : 'http://pili-live-hdl.miaobolive.com/live/e160addb5b2e5f8123de6cb0c6e1956b.flv', 
                'savePath': 'target',
                'companyId':2,
                'taskId':3
            } 
information = json.dumps(information)
# 10.0.0.59
## 数据打包传输
response = requests.post(interfaceurl, data=information)
# print(response)
print(response.json())
# requests.post(interfaceurl, data=information)