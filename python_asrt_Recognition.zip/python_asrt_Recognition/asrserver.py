import http.server
import urllib
import socket
from numpy.core.numeric import Inf
from numpy.lib.npyio import save
from speech_model import ModelSpeech
from speech_model_zoo import SpeechModel251
from speech_features import Spectrogram
from LanguageModel2 import ModelLanguage
import json
import librosa
from utils.ops import read_wav_data
from flask import Flask, request
import time
import os
import requests
import threading
from threading import Thread
class MyThread(Thread):
    def __init__(self, func, args):
        self.lock = threading.RLock()
        super(MyThread, self).__init__()
        self.func = func
        self.args = args

    def run(self):
        # 锁上
        self.lock.acquire()  
        self.result = self.func(*self.args)
        # 解锁
        self.lock.release()

    def get_result(self):
        try:
            return self.result
        except Exception:
            return None
# 定义一个拿出敏感词库的函数
def read_txt(file):
    with open(file ,encoding='utf-8') as f:
        data = f.read()
        list_data = data.split('\n')
        # 关闭文件很重要
        f.close()
        return list_data


# 定义一个语音识别函数
def video_to_word(path,save_path,company_id,task_id):
    try:
        now = time.strftime("%Y-%m-%d-%H_%M_%S",time.localtime(time.time()))
        file_path = save_path + '/' + now+ '.wav'
        if not os.path.exists(save_path):
                # print('已经创建路径'+ save_path)
                os.makedirs(save_path)
        # 执行save命令
        save_cmd = "ffmpeg -loglevel quiet -i %s -t 5 -f wav -ar 16000 %s"%(path,file_path)
        os.system(save_cmd)
        # 获取音频数组形式(wavsignal)
        print('----------------------')
        wavsignal, fs, _, _ = read_wav_data('%s'%(file_path))
        # 转换为拼音
        r_speech = ms.recognize_speech(wavsignal, fs)
        # 转换为文本
        r_text = ml.SpeechToText(r_speech)
        print('+++++++')
        print(r_text)
        print('+++++++')
        """进行敏感词判断"""
        content = ''
        for word in read_txt('./targetword/target.txt'):
            if word in r_text:
                # print('-------')
                content = content + word + ','
                # print(word)
                # print('-------')
        if len(content) != 0:
            print('java接口已经调用了')
            """调用java接口"""
            send_data = {
                'taskId':task_id,
                'companyId':company_id,
                'imgUrl':file_path,
                'content':content[:-1:]
                
            }
            # print(send_data)
            # 字典数据转为json数据
            send_data = json.dumps(send_data)
            # 发送相关参数
            # 亦Content-Type':'application/json的方式提交json请求
            response = requests.post('http://10.8.0.42:8088/wx/photo/saveVoidWarning', headers={'Content-Type':'application/json'}, data=send_data)
            return json.dumps(200,ensure_ascii=False)
        elif len(content) == 0:
            # 删除非敏感语音
            os.remove(file_path)
            return json.dumps(200,ensure_ascii=False)
                
    except:
       return json.dumps(500,ensure_ascii=False)

    
      
        
"""flask接口"""
server = Flask(__name__)
@server.route('/gttx/objectrecognition', methods=['post'])
def objectrecognition():
    """
    通过接口解析json数据
    """
    if not request.data:
        # 返回没有数据
        return json.dumps(500,ensure_ascii=False)
        # return json.dumps("{'message': 'None'}",ensure_ascii=False)
    # 以utf-8编码接收json数据
    information = request.data
    # 解析json数据为字典格式
    information = json.loads(information)
    # print('------------')
    # print(information)
    # print('------------')
    # return json.dumps(200,ensure_ascii=False)
    
    # # 获取变量
    path = information['path']
    save_path = information['savePath']
    # save_path = 'target'
    company_id = information['companyId']
    task_id = information['taskId']

    # 调用函数传入视频路径
    # 调用多线程实现异步处理
    MyThread(video_to_word,args=(path,save_path,company_id,task_id)).start()
    # result = video_to_word(path,save_path,company_id,task_id)
    return json.dumps(200,ensure_ascii=False)

if __name__ == '__main__':
    """基础模型导入"""
    # resample_rate('test.wav')
    audio_length = 1600
    audio_feature_length = 200
    channels = 1
    # 默认输出的拼音的表示大小是1428，即1427个拼音+1个空白块
    output_size = 1428
    sm251 = SpeechModel251(
        input_shape=(audio_length, audio_feature_length, channels),
        output_size=output_size
        )
    feat = Spectrogram()
    ms = ModelSpeech(sm251, feat, max_label_length=64)
    ms.load_model('save_models/' + sm251.get_model_name() + '.model.h5')
    ml = ModelLanguage('model_language')
    ml.LoadModel()

    """启动flask服务"""
    # 指定端口,host,0.0.0.0代表不管几个网卡，任何ip都可访问
    # server.run(debug=True, threaded=True,port=5000, host='127.0.0.1') # 多线程指定
    # 多进程指定，各个进程之间不冲突
    server.run(debug=False, processes=True,port=5100, host='0.0.0.0')