"""Perform test request"""
import pprint
import json
import requests

# DETECTION_URL = "http://localhost:5000/v1/gttx/objectrecognition"
# TEST_IMAGE = r"C:\Users\15256\Desktop\yolov5_v3.0\yolov5\data\images\bus.jpg"
# image_data = open(TEST_IMAGE, "rb").read()

# response = requests.post(DETECTION_URL, files={"image": image_data}).json()
## 定义访问接口
interfaceurl = "http://localhost:5000/v1/gttx/objectrecognition"

## 将要传入的数据设置为json格式
information = { 'imagepath' : 'C:/Users/15256/Desktop/yolov5_v3.0/yolov5/data/images/bus.jpg',  
        'mode' : 'yolov5s' } 
information = json.dumps(information)
print(information)
## 数据打包传输
response = requests.post(interfaceurl, data=information)
print(json.loads(response)).txt