import argparse
import io
import json
import torch
from PIL import Image
from flask import Flask, request
from torch._C import device
import time
import os
# sourceimage_dir = '../yolov5_v3.0/sourceimage'
# print(os.path.abspath(os.path.join(os.getcwd(), "../")))

# for root, dirs, files in os.walk(sourceimage_dir):
#     for img in files:
#         print(root+img)

# 变量需要识别的图片文件夹 ../路径指的是interface

# 相对路径的方式导入mymodes下的yolov5s1.pt这个模型
model = torch.hub.load('../yolov5_v3.0/yolov5', 'custom', path='../yolov5_v3.0/mymodes/yolov5s1.pt', source='local') 
# 获取图片路径
sourceimage_dir = '../yolov5_v3.0/sourceimage'
# 遍历出图片
for root, dirs, files in os.walk(sourceimage_dir):
    for imagename in files:
        # 拼接图片路径
        imagepath = root + '/'+ imagename

        # 打开图片的二进制数据
        image_string = open('%s'%(imagepath), 'rb').read()

        # 打开二进制数据流
        img = Image.open(io.BytesIO(image_string))

        # 将图片加载进模型种识别判断
        results = model(img, size=640)

        # print(results.pandas().xyxy[0])
        #print(results.pandas().xyxy[0].to_json(orient="records"))
        # 把获取到的json数据转换成字典格式
        
        """
        获取图片详细信息,只对某一类数据有效
        """
        results_objectrecognition = json.loads(results.pandas().xyxy[0].to_json(orient="records"))
        # 判断是否有目标图片
        if results_objectrecognition:
            # print('---------')
            # print(results_objectrecognition)
            # print('---------')
            name = results_objectrecognition[0]['name']
            confidence = results_objectrecognition[0]['confidence']
            xmin = results_objectrecognition[0]['xmin']
            ymin = results_objectrecognition[0]['ymin']
            xmax = results_objectrecognition[0]['xmax']
            ymax = results_objectrecognition[0]['ymax']
            if confidence == confidence:
                # print('++++++++++++++')
                # print(name,confidence)
                # print(results_objectrecognition[0])
                # print('++++++++++++++')
                pass
        else:
            pass
            
### opencv降低图片分辨率
import cv2
import os

curDir = os.curdir  # 获取当前执行python文件的文件夹
sourceDir = os.path.join(curDir, 'picture')
resultDir = os.path.join(curDir, 'resolution_lower')

def resolution_lower_handler(sourceDir, resultDir):
    img_list = os.listdir(sourceDir)

    for i in img_list: 
        pic = cv2.imread(os.path.join(sourceDir, i), cv2.IMREAD_COLOR)
        pic_n = cv2.resize(pic, (1280, 720))
        pic_name = i
        cv2.imwrite(os.path.join(resultDir, i), pic_n)

if __name__ == '__main__':
    resolution_lower_handler(sourceDir, resultDir)
