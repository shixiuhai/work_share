"""Perform test request"""
import pprint
import json
import requests

## 定义访问接口
interfaceurl = "http://localhost:5000/gttx/objectrecognition"

## 将要传入的数据设置为json格式
information = { 'imagedir' : 'sourceimage',  
                'mode' : 'yolov5s',
                'confidence':'0.3'} 
information = json.dumps(information)

## 数据打包传输
response = requests.post(interfaceurl, data=information)
print(response.json())