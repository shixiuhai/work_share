"""
Run a rest API exposing the yolov5s object detection model
"""
import argparse
import io
import json
import torch
from PIL import Image
from flask import Flask, request
from torch._C import device
import time
import os
import cv2 
"""
写一个smoke flask 接口
"""

server = Flask(__name__)
@server.route('/gttx/objectrecognition', methods=['post'])

def objectrecognition():
    # 定义一个统计违规图片的数量的计数器
    count = 0
    """
    通过接口解析json数据
    """
    if not request.data:
        # 返回没有数据
        return json.dumps("{'message': '没有数据'}",ensure_ascii=False)
    # 以utf-8编码接收json数据
    information = request.data
    # 解析json数据为字典格式
    information = json.loads(information)

    """
    获取图片路径，模型，命中概率设置
    """
    # 获取图片路径信息
    imagedir = information['imagedir']
    print(information['imagedir'])
    # 获取模型信息
    mode = information['mode']
    print(information['mode'])
    # 获取命中率信息
    confidence = information['confidence']
    print(confidence)

    """
    进行识别判断
    """
    # 变量需要识别的图片文件夹 ../路径指的是interface
    # 获取图片路径
    # sourceimage_dir = '../yolov5_v3.0/sourceimage'

    # 遍历出图片
    for root, dirs, files in os.walk(imagedir):
        # 获取文件夹下所以图片的名字
        for imagename in files:
            # 拼接图片路径
            imagepath = root + '/'+ imagename

            # 操作二进制数据
            image_string = open('%s'%(imagepath), 'rb').read()

            # 打开二进制数据流
            img = Image.open(io.BytesIO(image_string))

            # 将图片加载进模型中识别判断
            results = model(img, size=640)
            """
            获取图片详细信息,只对某一类数据有效
            """
            results_objectrecognition = json.loads(results.pandas().xyxy[0].to_json(orient="records"))
            # 判断是否有目标图片
            print(results_objectrecognition)
            if results_objectrecognition:
                # 进行计数
                count = count + 1
                # print('---------')
                # print(results_objectrecognition)
                # print('---------')
                name = results_objectrecognition[0]['name']
                confidence_result = results_objectrecognition[0]['confidence']
                xmin = results_objectrecognition[0]['xmin']
                ymin = results_objectrecognition[0]['ymin']
                xmax = results_objectrecognition[0]['xmax']
                ymax = results_objectrecognition[0]['ymax']
                # 把这四个做标转换为x,y,width,height
                x = int(xmin)
                y =  int(ymin)
                w =  int(xmax-xmin+1)
                h =  int(ymax-ymin+1)
                # print('-----------')
                # print(x,y,w,h)
                # print('-----------')
                # 提取出大于传入数据命中率阈值的图片
                if float(confidence_result) >= float(confidence):
                    """
                    将目标图片写入到存放违规图片的文件夹
                    """
                    # 读取图片
                    picture = cv2.imread(imagepath)
                    # print('---------')
                    # print(xmin,xmax,ymin,ymax)
                    # print('--------------')
                    # 画出目标区域!!! cv2.rectangle只支持整数
                    cv2.rectangle(picture, (x, y), (x + w, y + h), (0, 252, 124), thickness=1)
                  
                    # 写入目标图片到targetimage文件夹下面
                    cv2.imwrite('../yolov5_v3.0/targetimage/%s'%(imagename), picture)
                    


                    pass
                # print('++++++++++++++')
                # print(name,confidence)
                # print(results_objectrecognition[0])
                # print('++++++++++++++')
            else:
                pass
            # print(results_objectrecognition)



    """
    通过接口返回数据
    """
    # 返回违规图片有多少张
    result_information = {
        'tagetiamgenumber':count
    }
    return json.dumps(result_information,ensure_ascii=False)

  
    # resu = {'code': 200, 'message': '查询失败'}
    # return json.dumps(resu, ensure_ascii=False)  # 将字典转换为Json串，json是字符串

if __name__ == '__main__':
    """ 
    加载模型 
    """
    # 相对路径的方式导入mymodes下的yolov5s1.pt这个模型
    model = torch.hub.load('../yolov5_v3.0/yolov5', 'custom', path='../yolov5_v3.0/mymodes/smoke20.pt', source='local') 
    """
    启动flask服务
    """
    # 指定端口,host,0.0.0.0代表不管几个网卡，任何ip都可访问
    server.run(debug=True, port=5000, host='127.0.0.1')




















    # start = time.time()
    # model = torch.hub.load(r'C:\Users\15256\Desktop\interface\yolov5_v3.0\yolov5_v3.0\yolov5', 'custom', path=r'C:\Users\15256\Desktop\interface\yolov5_v3.0\yolov5_v3.0\mymodes\yolov5s1.pt', source='local') 
    # image_string = open(r'C:\Users\15256\Desktop\interface\yolov5_v3.0\yolov5_v3.0\yolov5\data\images\bus.jpg', 'rb').read()
    # img = Image.open(io.BytesIO(image_string))
    # results = model(img, size=640)  # reduce size=320 for faster inference
    # print(results.pandas().xyxy[0].to_json(orient="records"))
  

    
    
    # end = time.time()
    # print(end-start)
    # return results.pandas().xyxy[0].to_json(orient="records")















