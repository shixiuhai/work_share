import os
a=[1,2]
b={3,4}
if a == []:
    print('a')
if b != {}:
    print('bbb')
basket = {'apple', 'orange', 'apple', 'pear', 'orange', 'banana'}
for i in basket:
    print(i)
# print(basket['apple'])
#os.remove(r'C:\Users\15256\Desktop\interface\yolov5_v3.0\yolov5\utils\flask_rest_api\1.txt')
