"""
Run a rest API exposing the yolov5s object detection model
"""
import argparse
import io

import torch
from PIL import Image
from flask import Flask, request
from torch._C import device

app = Flask(__name__)

DETECTION_URL = "/v1/object-detection/yolov5s"


@app.route(DETECTION_URL, methods=["POST"])
def predict():
    if not request.method == "POST":
        return

    if request.files.get("image"):
        image_file = request.files["image"]
        image_bytes = image_file.read()

        img = Image.open(io.BytesIO(image_bytes))

        results = model(img, size=640)  # reduce size=320 for faster inference
        return results.pandas().xyxy[0].to_json(orient="records")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Flask API exposing YOLOv5 model")
    parser.add_argument("--port", default=6000, type=int, help="port number")
    args = parser.parse_args()
    #model = torch.hub.load('ultralytics/yolov5', 'custom', path=r'C:\Users\15256\Desktop\ultralytics_yolov5_master\ultralytics_yolov5_master\yolov5s.pt')  # default
    # model = torch.hub.load("ultralytics/yolov5", "yolov5s", force_reload=False)  # force_reload to recache
    model = torch.hub.load('../yolov5', 'custom', path='../mymodes/yolov5s1.pt', source='local') 
    app.run(host="0.0.0.0", port=args.port)  # debug=True causes Restarting with stat
    # 导入本地模型写法
    # model = torch.hub.load('ultralytics/yolov5', 'custom', path='path/to/best.pt')  # default
    """path/to/yolov5是yolov5项目路径; path/to/best/best.pt是自己best.pt文件路径"""
    # model = torch.hub.load('path/to/yolov5', 'custom', path='path/to/best.pt', source='local')  # local repo
