"""
接收getinformation传入的数据
"""
# # 吸烟类
# def smoke():
#     pass

# # 第二类
# def class2():
#     pass
import argparse
import io
import json
import torch
from PIL import Image
from flask import Flask, request
from torch._C import device
import time

start = time.time()
model = torch.hub.load(r'C:\Users\15256\Desktop\interface\yolov5_v3.0\yolov5_v3.0\yolov5', 'custom', path=r'../../mymodes/yolov5s1.pt', source='local') 
image_string = open(r'C:\Users\15256\Desktop\interface\yolov5_v3.0\yolov5_v3.0\yolov5\data\images\bus.jpg', 'rb').read()
img = Image.open(io.BytesIO(image_string))
results = model(img, size=640)  # reduce size=320 for faster inference
print(results.pandas().xyxy[0].to_json(orient="records"))




end = time.time()
print(end-start)
print(results.pandas().xyxy[0].to_json(orient="records"))



