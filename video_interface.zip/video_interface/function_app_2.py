"""
flask接口传入的数据会在这里进行处理
"""
from class_app_3 import *
import json
from kafka_listen_4 import *
"""kafka 服务器地址等相关信息"""
server_ip = '183.131.192.8:9092'
"""调用接口的信息"""
interfaceurl = "http://localhost:5000/gttx/objectrecognition"
def smoke(data):
    """
    data 是一个json字典数据流
    这里的传入的数据格式是
    'path' : 'path',  
    'id' :'4',
    'type':'smoke',
    'status':'0',
    'confidence': '0.3'
    """
    """判断kafka消息"""
    # 对象字符串的名字 比如 obj_smoke_4
    obj_name_string = ('obj'+ '_' + data['type'] + '_' + data['id'])

    # 判断当前状态
    if data['status'] == '0':
        # 发送关闭状态到kafka
        kafka_producer({'status':'0'},server_ip,(data['type']+data['id']))
        # 结束这个flask进程
        return None
    
    # status_value 表示status状态，当status状态等于1的时候创建对象
    elif data['status'] == '1':
        """将关闭状态发送给kafka服务器 为了避免同一个对象创建两次"""
        kafka_producer({'status':'0'},server_ip,(data['type']+data['id']))

        """ 将开启状态发送给kafka服务器 为了避免同一个对象创建两次"""
        kafka_producer({'status':'1'},server_ip,(data['type']+data['id']))
        
        """创建对象"""
        # path,id,type,confidence,obj_name_string)
        # path(视频路径), id(摄像头编号), type(选择的模型类型),confidence（模型识别信任度）,obj_name_string（对象名的字符串形式）
        obj_name = vars()[obj_name_string] = Process_video(data['path'],data['id'],data['type'],data['confidence'],obj_name_string)

        """调用一下 是否开关的心跳接口 方法"""
        # 对象调用一下是否开关的心跳接口
        # obj_status(无需传入参数)
        MyThread(obj_name.obj_status,args=()).start()

        """调用一下 错误自动重启 方法"""
        # obj_restart(interface_url,data)
        # MyThread(obj_name.obj_restart,args=(interfaceurl,data,)).start()

        """调用一下 视频拼接_标出对象_rtmp推流 方法""" 
        # 传入的参数是(video_fps,rtmp_fps) video_frp是解析视频的帧率,rtmp_fps是推流帧率
        MyThread(obj_name.video_mark_savepicture_push,args=(20,10)).start()
       


def person(data):
    obj_name = vars()[('obj'+'%s'%data['id'])] = Process_video(data['type'])
    MyThread(obj_name.test1,args=()).start()

def mask(data):
    pass    

def other(data):
    pass