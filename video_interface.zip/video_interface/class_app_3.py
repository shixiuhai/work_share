"""
导入相关的库和函数
"""
from logging import error
import threading
from threading import Lock, Thread
import os
import cv2 
import argparse
import io
import json
from torch._C import  device
import torch
import time
import requests
from kafka_listen_4 import *
from PIL import ImageDraw,Image,ImageFont
import numpy as np
import subprocess
"""kafka 服务器地址等相关信息"""
server_ip = '183.131.192.8:9092'
"""
这是一个对视频进行处理的类
算法基于yolov5 训练框架基于pytorch
"""
# 'path' : r'C:\Users\15256\Desktop\nowtime\吸烟视频\2.mp4',  
# 'id' :'3',
# 'type':'smoke',
# 'status':'1',
# 'confidence': '0.5'
class Process_video():
    """类初始化的变量"""
    # path 视频路径, id 摄像头的编号,confidence 置信度, obj_name_string 对象的字符串名字
    def __init__(self,path,id,type,confidence,obj_name_string) :
        # 视频路径
        self.path = path

        # 视频id
        self.id = id
        
        # 模型类型
        self.type = type

        # 对象字符串名字
        self.obj_name_string = obj_name_string

        # 置信度参数
        self.confidence = confidence

        # 加载模型
        self.model = torch.hub.load('yolov5', 'custom', path='models/%s.pt'%(self.type), source='local')
        
        # 定义一个图片的全局变量 self.picture是opencv格式的图片是一个三维数组
        self.picture=''
        
        # 定义一个开关状态相关的全局变量
        self.status = '1'
        
        # 打印创建对象成功的消息
        print('----------------------')
        print('创建对象%s成功'%self.obj_name_string)
        print('----------------------')

    # 定义一个销毁对象的方法，释放内存空间
    def __del__(self):
        print("调用__del__()方法销毁 " + self.obj_name_string + " 对象，释放其空间")
    
    def video_mark_savepicture_push(self,video_fps,rtmp_fps):
        # 创建对象
        cap = cv2.VideoCapture(self.path)
        # 显示图片的宽设置
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        # 显示图像的高设置
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        print('video_mark_savepicture_push已经进入++++++++++++++++++++++++')

        # 调用 单帧识别画框 方法
        # identification_frequency 就是延迟时间
        MyThread(self.draw_picture,args=(0.1,)).start()

        # 调用 推流方法
        # push_stream(self,rtmp_url,rtmp_fps,width,height)
        MyThread(self.push_stream,args=("rtmp://104.225.236.140:1935/stream/%s"%(self.obj_name_string),rtmp_fps,width,height)).start()


        while cap.isOpened():
            ret, frame = cap.read()
            # cv2.imwrite('./1.jpg',frame)
            # status 状态判断
            if self.status == '0':
                # 释放cap对象
                cap.release() 
                break
            elif self.status == '1':
                time.sleep(1/video_fps)
                if not ret:
                    # 调用kafka发送错误信息
                    kafka_producer({'status':'0'},server_ip,(self.type+self.id))
                    print(self.obj_name_string + "打开视频源失败")
                    break
                self.picture = frame
                # self.draw_picture(0.1)
                # cv2.imshow('img'+path,self.picture)
                cv2.waitKey(1)
     
            
    """单帧识别画框_保存图片 方法"""
    # picture 是opencv读取到的图片 ，model是模型，identification_frequency是识别频率,比如identification_frequency代表1s钟识别一次
    def draw_picture(self,identification_frequency):
        
        # time.sleep(2) 等待 self.picture获取图片内容
        time.sleep(identification_frequency)
        try:
            while True:
                if self.status =='0':
                    break
                elif self.status == '1':
                    time.sleep(identification_frequency)
                    img = Image.fromarray(cv2.cvtColor(self.picture,cv2.COLOR_BGR2RGB))  
                    # print(img)
                    # 调用模型
                    results = self.model(img, size=640)
                    # 获取到图片画框json数据
                    results_objectrecognition = json.loads(results.pandas().xyxy[0].to_json(orient="records"))
                    for i in range(len(results_objectrecognition)):
                        # 这里面有多个
                        # 取出每个对象返回的 json 结果
                        name = results_objectrecognition[i]['name']
                        # confidence_result是浮点型数据
                        confidence_result = results_objectrecognition[0]['confidence']
                        xmin = results_objectrecognition[i]['xmin']
                        ymin = results_objectrecognition[i]['ymin']
                        xmax = results_objectrecognition[i]['xmax']
                        ymax = results_objectrecognition[i]['ymax']
                        # 把这四个做标转换为x,y,width,height
                        x = int(xmin)
                        y =  int(ymin)
                        w =  int(xmax-xmin+1)
                        h =  int(ymax-ymin+1)
                        print('置信度是%s'%confidence_result)
                        if confidence_result >= float(self.confidence):
                            """
                            将目标图片写入到存放违规图片的文件夹
                            """
                            # 画框
                            pic= cv2.rectangle(self.picture, (x, y), (x + w, y + h), (0, 0, 255), thickness=3)
                            # cv2.putText(picture)
                            # 添加中文显示
                            # image,strs,local(图片的坐标),sizes,color 
                            pic = self.change_cv2_draw(self.picture,"%s %.2s%%"%(self.type,confidence_result*100),(x+w+5,y-5),30,(255,0,0))
                            # 将画好的图片赋值给self.picture 这个全局变量
                            # for i in range(100):

                            self.picture = pic
                            # cv2.imwrite('target_images/2.jpg',self.picture)
                            # cv2.imwrite("%s/'%s'.jpg"%('target_images',time.strftime('%Y-%m-%d-%H:%M:%S',time.localtime(time.time()))),self.picture)
                            self.save_images('target_images')
        except:
            # 调用kafka发送错误消息
            kafka_producer({'status':'0'},server_ip,(self.type+self.id))
            print(self.obj_name_string + '视频取帧识别保存出错')
       
                   
    """推流"""
    # rtmp_url是推流的地址,rtmp_fps是推流的fps,widht和height是推流图像的分辨率（宽和高）
    def push_stream(self,rtmp_url,rtmp_fps,width,height):
        # time.sleep(2) 等待 self.picture获取图片内容
        time.sleep(6)
        # command定义
        command = [r'C:\Users\15256\Downloads\2021-10-26-00-34-45-www.gyan.dev-ffmpeg-4.4.1-full_build-shared\ffmpeg-4.4.1-full_build-shared\bin\ffmpeg.exe',
        '-y',
        '-f', 'rawvideo',
        '-vcodec', 'rawvideo',
        '-pix_fmt', 'bgr24',
        '-s', "{}x{}".format(width, height),
        '-r', str(rtmp_fps),
        '-i', '-',
        '-c:v', 'libx264',
        '-pix_fmt', 'yuv420p',
        '-preset', 'ultrafast',
        '-f', 'flv',
        rtmp_url]

        pipe = subprocess.Popen(command, shell=False,  stdin=subprocess.PIPE)
        try:
            while True:
                time.sleep(1/rtmp_fps)
                print('%s在推流中'%(self.obj_name_string))
                # status 状态判断
                if self.status == '0' :
                    pipe.stdin.close()  # 关闭输入管道
                    # pipe.communicate()  # 等待子进程关闭
                    break
                    
                elif self.status == '1':
                    pipe.stdin.write(self.picture.tostring())
        except:
            # 调用kafka发送错误消息
            kafka_producer({'status':'0'},server_ip,(self.type+self.id))
            print('%s推流出错了'%(self.obj_name_string))
       
               
    """保存图片 方法"""
    # save_path就是需要将 BGR 通道流的图片保存位置
    def save_images(self,save_path):
        # 获取当前时间的字符串
        now = time.strftime("%Y-%m-%d-%H_%M_%S",time.localtime(time.time())) 
        cv2.imwrite("%s/%s_(%s).jpg"%(save_path,now,self.obj_name_string),self.picture)
        
        
    """通过kafka 做一个对象开关的方法"""
    def obj_status(self):
        while True:
            # kafka_consumer(group_id,server_ip,topic,value_key
            if  kafka_consumer(server_ip,(self.type+self.id),'status') == '0':
                self.status = '0'
                # # 关闭重启方法
                # kafka_producer({'error_status':'1'},server_ip,(self.type+self.id))
                self.__del__
                print('对象'+ self.obj_name_string+'已经删除')
                break

    """通过kafka 做一个对象自动重新启动 的方法"""
    # # interface_url是接口地址,data 是传入的json数据
    # def obj_restart(self,interface_url,data):
    #     while True:
    #         if kafka_consumer((self.type+self.id),server_ip,(self.type+self.id),'error_status') == '1':
    #             if self.status == '1':
    #                 # print(self.obj_name_string + '准备重启')
    #                 # 发送关闭消息给kafka
    #                 kafka_producer({'status':'0'},server_ip,(self.type+self.id))
    #                 # time.sleep(10)
    #                 # if (requests.post(url=interface_url, data= json.dumps(data))).json()['result'] == '1':
    #                 #     print(self.obj_name_string + '重启成功')
    #                 # else:
    #                 #     print('接口错误')
    #             elif self.status == '0':
    #                 break
    # 'path' : 'path',  
    # 'id' :'4',
    # 'type':'smoke',
    # 'status':'0',
    # 'confidence': '0.3'
    # interface_url是传入的url, data是传入的json数据, monitor_time是监听时间,server_ip是kafka服务器ip，topic是
    # def obj_restart(self,interface_url,data,monitor_time):
    #     while True:
    #         # 监听对象状态异常的延迟时间
    #         time.sleep(monitor_time)
    #         print('%s错误状态监听中'%(self.obj_name_string))
    #         # 监听时间判断status状态
    #         if self.status == '0':
    #             print(self.obj_name_string + '已经关闭')
    #             break
    #         elif self.status == '1':
    #             # 监听完成后判断 status状态
    #             if self.error_value == '1':
    #                 # 发送一条信息给kafka心跳接口，实现心跳接口线程关闭
    #                 kafka_producer({'status':'0'},server_ip,(self.type+self.id))
    #                 # print(self.obj_name_string+ '准备重启')
    #                 # if (requests.post(url=interface_url, data= json.dumps(data))).json()['result'] == '1':
    #                 #     print(self.obj_name_string + '重启成功')
    #                 #     # 等待别的进程全部关闭
    #                 #     time.sleep(15)
    #                 # else:
    #                 #     print('请求接口失败，服务关闭')
                    
        

    """定义一个可以在图片上添加中文的方法"""
    # 吸烟 %.2s%%"%(confidence_result*100),(x+w+5,y-5),30,(255,0,0))
    # image是图片 strs是中文汉字 local是做标 size 是字体尺寸 colour是颜色的RGB码
    def change_cv2_draw(self,image,strs,local,sizes,colour):
        cv2img = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        pilimg = Image.fromarray(cv2img)
        draw = ImageDraw.Draw(pilimg)  # 图片上打印
        font = ImageFont.truetype("SIMYOU.TTF",sizes, encoding="utf-8")
        draw.text(local, strs, colour, font=font)
        image = cv2.cvtColor(np.array(pilimg), cv2.COLOR_RGB2BGR)
        return image
    

"""
这是一个使用多线程的类
"""
class MyThread(Thread):
    def __init__(self, func, args):
        self.lock = threading.RLock()
        super(MyThread, self).__init__()
        self.func = func
        self.args = args

    def run(self):
        # 锁上
        self.lock.acquire()  
        self.result = self.func(*self.args)
        # 解锁
        self.lock.release()

    def get_result(self):
        try:
            return self.result
        except Exception:
            return None




































# class Test():
#     def __init__(self) -> None:
#         self.ab = 5

#     def __del__(self):
#         print('线程删除成功')


#     def test1(self,a,b,c):
#         while True:
#             time.sleep(2)
#             self.ab = self.ab +1
#             print('test1')
#             print(self.ab)
            

#     def test2(self,a,b,c):
#         while True:
#             time.sleep(1)
#             self.ab =self.ab-1
#             print(self.ab)
#             print('test2')
#     def test3(self):
#         time.sleep(3)
#         self.__del__()
#         print('对象删除完成')


# at = Test()
# def t(a,b,c):
#     print('hello word')
# # a.test2(1,2,3)
# MyThread(at.test1,args=(1, 2,5,)).start()
# MyThread(at.test2,args=(1, 2,5,)).start()
# MyThread(at.test3,args=()).start()


# t1.start()
# t2.start()
# time.sleep(2)
# t1.join()
# t2.join()

# a = 2
# def add():
#     global a
#     while True:
#         time.sleep(5)
#         a = a+1
    
#         print(a)
# def sum():
#     global a
#     while True:
#         time.sleep(10)
        
#         a = a-1
#         print(a)

# MyThread(add,args=()).start()
# MyThread(sum,args=()).start()