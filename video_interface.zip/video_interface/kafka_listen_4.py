from kafka import KafkaConsumer,KafkaProducer
import json
"""
data = {'value_1' : 'value_2'}
producer = KafkaProducer(bootstrap_servers=['183.131.192.8:9092'], value_serializer=lambda m: json.dumps(m).encode())
future = producer.send('my' ,  value=data , partition= 0)
future.get(timeout= 3)
"""
"""
server_ip 是服务器ip+端口的形式 ip:port 这里为了保证唯一将topic 和 group_id设置成一样的
"""

def kafka_producer(producer_data,server_ip,topic):
    producer = KafkaProducer(bootstrap_servers=[server_ip], value_serializer=lambda m: json.dumps(m).encode())
    future = producer.send(topic,  value=producer_data , partition= 0)
    future.get(timeout= 3)
    


def kafka_consumer(server_ip,topic,value_key):
    # consumer_timeout_ms=1000
    # consumer = KafkaConsumer(topic,group_id = group_id, bootstrap_servers= [server_ip], auto_offset_reset='latest',enable_auto_commit = True,
    # auto_commit_interval_ms = 1,value_deserializer=lambda m: json.loads(m.decode('ascii')))
    consumer = KafkaConsumer(topic,
    bootstrap_servers= [server_ip],
    value_deserializer=lambda m: json.loads(m.decode('ascii')))
    for msg in consumer:
        dic = eval(str(msg.value))  
        try:
            return dic[value_key]
        except:
            pass
    
