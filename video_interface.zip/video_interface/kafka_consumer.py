from kafka import KafkaConsumer
import json
import time
from kafka_listen_4 import *
# 调用测试
server_ip = '183.131.192.8:9092'
topic = 'smoke3'
value_key = 'status0'
# 消息消费
# while True:
while True:
    print(kafka_consumer('5',server_ip,topic,value_key))
    break
      