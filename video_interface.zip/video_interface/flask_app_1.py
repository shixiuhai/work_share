"""
通过此flask 接口调用多个函数实现功能
"""
from class_app_3 import *
import argparse
import io
import json
import torch
from PIL import Image
from flask import Flask, request
# from torch._C import device
import time
import os
from function_app_2 import * # 导入function_app_2.py里面所有的函数
from kafka import KafkaConsumer,KafkaProducer
server = Flask(__name__)
@server.route('/gttx/objectrecognition', methods=['post'])
def objectrecognition():
    """
    通过接口解析json数据
    """
    if not request.data:
        # 返回没有数据
        return json.dumps("{'message': 'None'}",ensure_ascii=False)
    # 以utf-8编码接收json数据
    information = request.data
    # 解析json数据为字典格式
    information = json.loads(information)
    try:
        type = information['type']
        """
        将传入的字符 type 传做为函数去调用function_app_2.py 下面代码的意思就是函数调用函数 smoke(information)
        """
        eval(type + "(%s)"%information) 
    
    except  TypeError as e:
        print(e)
        print('no this function or function error')
    return json.dumps({'result':'1'})
    # return json.dumps(information,ensure_ascii=False)
if __name__ == '__main__':
    """
    启动flask服务
    """
    # 指定端口,host,0.0.0.0代表不管几个网卡，任何ip都可访问
    # server.run(debug=True, threaded=True,port=5000, host='127.0.0.1') # 多线程指定
    # 多进程指定，各个进程之间不冲突
    server.run(debug=True, processes=True,port=5000, host='127.0.0.1')
    
