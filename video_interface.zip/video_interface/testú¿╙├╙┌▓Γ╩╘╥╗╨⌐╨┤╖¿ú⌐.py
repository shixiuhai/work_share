from kafka import KafkaConsumer,KafkaProducer
import json
import cv2
import time
# consumer = KafkaConsumer('my_topic', group_id= 'group2', bootstrap_servers= ['183.131.192.8:9092'])
# for msg in consumer:
#     print(msg)

# producer = KafkaProducer(bootstrap_servers=['183.131.192.8:9092'])
# future = producer.send('my_topic' , key= b'my_key', value= b'my_value', partition= 0)
# result = future.get(timeout= 10)
# print(result)
# consumer = KafkaConsumer('my_topic', group_id= 'group2', bootstrap_servers= ['localhost:9092'])
"""
生成端
"""
# data = json.dumps({'id':'id','status':'status'}).encode()
# producer = KafkaProducer(bootstrap_servers=['183.131.192.8:9092'])
# future = producer.send('test' , data, partition= 0)
# result = future.get(timeout= 10)
# print(result)
# data = {'value_1' : 'value_2'}

# producer = KafkaProducer(bootstrap_servers=['183.131.192.8:9092'], value_serializer=lambda m: json.dumps(m).encode())
# future = producer.send('my' ,  value=data , partition= 0)
# future.get(timeout= 3)

"""
消费者
"""

# consumer = KafkaConsumer('test', bootstrap_servers= ['183.131.192.8:9092'])
# for msg in consumer:
#     # print(msg)
#     print('---------')
#     print(msg)
#     print('------------')


import argparse
import io
import json
import torch
from PIL import Image
from flask import Flask, request
from torch._C import device
import time
import os

# 相对路径的方式导入mymodes下的yolov5s1.pt这个模型
# model = torch.hub.load('./yolov5', 'custom', path='models/smoke.pt', source='local') 
cap = cv2.VideoCapture('http://nvr.secserv.top:10800/flv/hls/stream_3.flv')
# 显示图片的宽设置
width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
# 显示图像的高设置
height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
video_fps = 5
while cap.isOpened():
    time.sleep(0.1)
    print('hello word')
    ret, frame = cap.read()
    # time.sleep(1/video_fps)
    
    if not ret:
        print("打开视频源失败")
    
    cv2.imshow('img',frame)
    # picture = Image.fromarray(cv2.cvtColor(frame,cv2.COLOR_BGR2RGB)) 
    # results = model(picture, size=640)
    # print(results)
    cv2.waitKey(1)
