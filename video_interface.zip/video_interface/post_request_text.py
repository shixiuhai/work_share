"""Perform test request"""
import pprint
import json
import requests
import argparse
import io
## 定义访问接口
interfaceurl = "http://localhost:5000/gttx/objectrecognition"

## 将要传入的数据设置为json格式
information = { 'path' : r'C:\Users\15256\Desktop\nowtime\吸烟视频\2.mp4',  
                'id' :'3',
                'type':'smoke',
                'status':'1',
                'confidence': '0.5'} 
information = json.dumps(information)

## 数据打包传输
response = requests.post(interfaceurl, data=information)
# print(response)
print(response.json()['result'])
# requests.post(interfaceurl, data=information)