from kafka_listen_4 import *
"""调用测试"""
server_ip = '183.131.192.8:9092'
producer_data =  {'status0':'2434'}
topic = 'smoke3'
# key_value = 'status1'
# 消息生产
kafka_producer(producer_data,server_ip,topic)