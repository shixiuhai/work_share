import requests 
import json
import time
def get_accesstoken():
    # client_id 为官网获取的AK， client_secret 为官网获取的SK
    host = "https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id=GfHScIUdOtlOSOVtGWtW1w6i&client_secret=c9HtDl7rGPwo6O9NznWy8xuxvj9nMXeN"
    response = requests.get(host)
    # print(response)
    if response:
        return response.json()['access_token']
# start = time.time()
# print(get_accesstoken())
# now = time.time()
# print(now-start)