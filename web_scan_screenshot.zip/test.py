from selenium import webdriver
import pymysql
import os
import time
import json
import requests
import random
from accetoken import *
import base64
import datetime
# def web_screenshot_review(url,save_path):
#     # 使用webdirver.PhantomJS()方法新建一个phantomjs的对象pa
#     # 此处添加phantomjs.exe的路径，否则会报错
#     brower = webdriver.PhantomJS(executable_path="C:/Users/15256/Downloads/phantomjs-2.1.1-windows/phantomjs-2.1.1-windows/bin/phantomjs.exe") 
#     brower.get(url) 
#     # print(len(brower.page_source))
#     brower.maximize_window()  
#     brower.viewportSize={'width':1024,'height':800}
#     # 如果保存的路径不存在就创建路径
#     if not os.path.exists(save_path):
#         # print('已经创建路径'+ save_path)
#         os.makedirs(save_path)
#     # 图片存储路径
#     now = time.strftime("%Y-%m-%d-%H_%M_%S",time.localtime(time.time()))
#     file_path = save_path + '/' + now + '.jpg'
#     if len(brower.page_source) != 39:
#         brower.save_screenshot(file_path)  
#         brower.quit()
#         """调用百度api接口对图像进行识别判断"""
#     else:
#         brower.quit()
#         print('无法访问此网站')
# web_screenshot_review('http://98neiyi.net','text3')
# a = [1,23,23]
# print(a[1::])
# 查询check_certificate
def sql_select(table_name):
    domains_list = []
    # 表名直接使用%s替代，表字段使用'%s'替代
    sql = "SELECT * FROM %s"%(table_name) 
    try:
        # 使用cursor()方法获取操作游标 
        cursor = db.cursor()
        # 执行SQL语句
        cursor.execute(sql)
        # 提交到数据库
        db.commit()
        # 获取所有记录列表
        results = cursor.fetchall()
        # print(results)
        # print(results)
        for i in results:
            print(i[1])
            domains_list.append(i[0])
            # print(i)
        return {
            'domains_list':domains_list
        }

          
    except:
       return '查询异常错误'

"""sql数据插入数据"""
"""sql数据插入数据"""
# company_name 公司名字,ip ip地址，domain域名,warn_content告警信息
def sql_execute(company_name,ip,domain,warn_content):
    # SQL 插入语句
    # 数据创建时间
    created_time=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    if company_name == None:
        company_name = 'Null'
        sql = "INSERT INTO check_certificate_warning(company_name, \
        ip, domain, warn_content,created_time) \
        VALUES (%s, '%s', '%s', '%s','%s')" % \
        (company_name,ip,domain,warn_content,created_time)
        
    else:
        sql = "INSERT INTO check_certificate_warning(company_name, \
        ip, domain, warn_content,created_time) \
        VALUES ('%s', '%s', '%s', '%s','%s')" % \
        (company_name,ip,domain,warn_content,created_time)
    try:
        # 使用cursor()方法获取操作游标 
        cursor = db.cursor()
        # 执行sql语句
        cursor.execute(sql)
        # 提交到数据库执行
        db.commit()
        """插入数据查看调试"""
        print("插入的数据为: '%s', '%s', %s, '%s', '%s'"%(company_name,ip,domain,warn_content,created_time))
        # time.sleep(2)
    except:
        print('错误')
        # 如果发生错误则回滚,在错误的实在再关闭数据库
        db.rollback()

"""执行的主函数"""
if __name__ == '__main__':
    """连接数据库"""
    # 打开数据库连接
    # db = pymysql.connect(host='localhost',
    #                     user='root',
    #                     password='Gttx@2020',
    #                     database='push')
    db = pymysql.connect(host='localhost',
                        user='root',
                        password='sxh.200008',
                        database='mydb')
    # sql_select('check_certificate')
    sql_execute(None,'121.3.2.4','www.baidu.com','没有备案')