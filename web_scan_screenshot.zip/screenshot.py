from selenium import webdriver
import pymysql
import os
import time
import json
import requests
import random
from threading import Thread
import threading
from accetoken import *
import datetime
# from PIL import Image
# from accetoken import *
import base64
"""
这是一个使用多线程的类
"""
"""生成随机整数"""
def create_random():
    return random.randint(1,3)
class MyThread(Thread):
    def __init__(self, func, args):
        self.lock = threading.RLock()
        super(MyThread, self).__init__()
        self.func = func
        self.args = args

    def run(self):
        # 锁上
        self.lock.acquire()  
        self.result = self.func(*self.args)
        # 解锁
        self.lock.release()

    def get_result(self):
        try:
            return self.result
        except Exception:
            return None

"""执行告警信息添加参数"""
"""sql数据插入数据"""
# company_name 公司名字,ip ip地址，domain域名,warn_content告警信息
def sql_execute(company_name,ip,domain,warn_content):
    # SQL 插入语句
    # 数据创建时间
    created_time=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    # 当company_name 为None时填入null到数据库
    if company_name == None:
        company_name = 'Null'
        sql = "INSERT INTO check_certificate_warning(company_name, \
        ip, domain, warn_content,created_time,send_type,type) \
        VALUES (%s, '%s', '%s', '%s','%s','%s','%s')" % \
        (company_name,ip,domain,warn_content,created_time,1,2)
        
    else:
        sql = "INSERT INTO check_certificate_warning(company_name, \
        ip, domain, warn_content,created_time,send_type,type) \
        VALUES ('%s', '%s', '%s', '%s','%s','%s','%s')" % \
        (company_name,ip,domain,warn_content,created_time,1,2)
    try:
        # 使用cursor()方法获取操作游标 
        cursor = db.cursor()
        # 执行sql语句
        cursor.execute(sql)
        # 提交到数据库执行
        db.commit()
        """插入数据查看调试"""
        print("插入的数据为: '%s', '%s', %s, '%s', '%s'"%(company_name,ip,domain,warn_content,created_time))
        # time.sleep(2)
    except:
        print('错误')
        # 如果发生错误则回滚,在错误的实在再关闭数据库
        db.rollback()

"""执行check_cerficate_deatil添加函数"""
# 存储合规和不合规，网站没有备案
def sql_execute_detail(ip,scan_base):
    sql = "INSERT INTO check_certificate_detail(check_certificate_id, \
        scan_base) \
        VALUES ('%s', '%s')" % \
        (ip,scan_base)
    try:
        # 使用cursor()方法获取操作游标 
        cursor = db.cursor()
        # 执行sql语句
        cursor.execute(sql)
        # 提交到数据库执行
        db.commit()
        """插入数据查看调试"""
        print("插入的数据为: '%s', '%s'"%(ip,scan_base))
        # time.sleep(2)
    except:
        print('错误')
        # 如果发生错误则回滚,在错误的实在再关闭数据库
        db.rollback()

"""执行sql语句查询""" 
# 查询check_certificate
def sql_select(table_name):
    domains_list = []
    ips_list = []
    company_names_list = []
    # 表名直接使用%s替代，表字段使用'%s'替代
    sql = "SELECT * FROM %s"%(table_name) 
    try:
        # 使用cursor()方法获取操作游标 
        cursor = db.cursor()
        # 执行SQL语句
        cursor.execute(sql)
        # 提交到数据库
        db.commit()
        # 获取所有记录列表
        results = cursor.fetchall()
        # print(results)
        for i in results:
            domains_list.append(i[1])
            ips_list.append(i[0])
            company_names_list.append(i[10])
        return {
            'domains_list':domains_list,
            'ips_list':ips_list,
            'company_names_list':company_names_list
        }

          
    except:
       return '查询异常错误'

"""定义一个图片审核函数"""
def picture_review(file_path,url,ip,company_name):
    request_url = "https://aip.baidubce.com/rest/2.0/solution/v1/img_censor/v2/user_defined"
    # 打开图片
    f = open('%s'%(file_path), 'rb')
    img = base64.b64encode(f.read())
    # !!!!!!!!!关闭文件很重要
    f.close()
    # 识别
    params = {"image":img}
    # access_token='24.70e37c419760b6ce8e2262d17699f676.2592000.1640838722.282335-25213635'
    access_token = '%s'%get_accesstoken()
    # access_token = '24.a6252d0fc87a8d462ccb4cb9f4a7e390.2592000.1640328040.282335-2521363'
    request_url = request_url + "?access_token=" + access_token
    headers = {'content-type': 'application/x-www-form-urlencoded'}
    response = requests.post(request_url, data=params, headers=headers)
    """告警信息判断"""
    if response.json()['conclusionType'] in [1,3,4]:
        print('网站合规')
        # 存储合规和不合规，网站没有备案
        time.sleep(create_random()/15)
        sql_execute_detail(ip,'网站合规')
    elif response.json()['conclusionType'] == 2:
        # 获取违规信息
        warn_content = ''
        for i in range(len(response.json())):
            warn_content = warn_content + response.json()['data'][i]['msg'] + ','
        
        # 存储合规和不合规，网站没有备案
        sql_execute_detail(ip,warn_content)
        time.sleep(0.1)
        # domain从url里面提取出来  warn_content[:-1:]去掉最后一个逗号
        sql_execute(company_name,ip,url[7::],warn_content[:-1:])
    # print(response.json())

"""截图加审核函数"""
def web_screenshot_review(url,ip,company_name,table_name,save_path):
    # 使用webdirver.PhantomJS()方法新建一个phantomjs的对象pa
    # 此处添加phantomjs.exe的路径，否则会报错
    brower = webdriver.PhantomJS(executable_path="C:/Users/15256/Downloads/phantomjs-2.1.1-windows/phantomjs-2.1.1-windows/bin/phantomjs.exe") 
    brower.get(url) 
    # print(len(brower.page_source))
    brower.maximize_window()  
    # brower.viewportSize={'width':1024,'height':800}
    # 如果保存的路径不存在就创建路径
    if not os.path.exists(save_path):
        # print('已经创建路径'+ save_path)
        os.makedirs(save_path)
    # 图片存储路径
    now = time.strftime("%Y-%m-%d-%H_%M_%S",time.localtime(time.time()))
    # 图片名字
    name_jgp = now+'.jpg'
    file_path = save_path + '/' + name_jgp
    if len(brower.page_source) != 39:
        # 设置图片保存大小
        brower.viewportSize={'width':1920,'height':1080}
        brower.save_screenshot(file_path)  
        # 退出浏览器
        brower.quit()
        try:
            """将路径存入pictrue_url里面"""
            """将图片地址存入数据库中"""
            # 因为url前面加过http所有现在传入的时候需要去掉http
            # print('存入')
            sql_update(url[7::],'7/%s'%name_jgp,table_name)
            """调用百度api接口对图像进行识别判断"""
            picture_review(file_path,url,ip,company_name)
        except:
            pass

    else:
        brower.quit()
        print('无法访问' + url + '此网站')
    

"""将截取到的图片路径放入到数据库中"""
def sql_update(domain,picture_url,table_name):
    print(domain,picture_url)
    # 表单是 check_certificate company_name 后面没有逗号！！！！
    sql_interface_in = "UPDATE %s SET picture_url = '%s' WHERE domain = '%s'" %(table_name,picture_url,domain)
    # 使用cusor()方法获取操作游标
    cursor = db.cursor()
    # 执行 IN 口数据插入
    cursor.execute(sql_interface_in)
    db.commit()
    print(domain + '更新成功')


"""执行的主函数"""
def main(table_name,save_path):
    # 查询域名
    domains_list = sql_select(table_name)['domains_list']
    ips_list = sql_select(table_name)['ips_list']
    company_names_list = sql_select(table_name)['company_names_list']
    print(len(domains_list),len(ips_list),len(company_names_list))
    # 查看一些列表长度
    length  = len(domains_list)

    count = 0 # 多线程使用
    for i in range(length):
        url = 'http://'+domains_list[i]
        ip = ips_list[i]
        company_name= company_names_list[i]
        # print(url,ip,company_name)
        print('-------------')
        print('检测的网站是'+url)
        print(url)
        try:
            # 加快速度可以考虑多线程
            # join()阻塞主线程，等待子线程完成后主线程才退出
            # 多线程
            MyThread(web_screenshot_review,args=(url,ip,company_name,table_name,save_path,)).start()
            # 单线程
            # web_screenshot_review(url,ip,company_name,table_name,save_path)
            count  = count +1 
            if count == 5:
                time.sleep(40)
                count = 0
            print('-------------')
        except:
            pass
    # 主线程等待15s
    time.sleep(40)
    # 关闭数据库
    db.close()
    print(domains_list)
if __name__ == '__main__':
    """连接数据库"""
    # 打开数据库连接
    # db = pymysql.connect(host='localhost',
    #                     user='root',
    #                     password='Gttx@2020',
    #                     database='push')
    db = pymysql.connect(host='localhost',
                        user='root',
                        password='sxh.200008',
                        database='mydb')
    # 数据表名 保存文件夹
    # main(table_name,save_path) table_name是表名,save_path图片是保存路径
    # table_name是源数据表
    main('check_certificate','text5')
    # web_screenshot('http://www.525baobao.com/','txt')