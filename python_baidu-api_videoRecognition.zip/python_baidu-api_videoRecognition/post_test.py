"""Perform test request"""
import pprint
import json
import requests
import argparse
import io
import threading
from threading import Thread

"""
这是一个使用多线程的类
"""
class MyThread(Thread):
    def __init__(self, func, args):
        self.lock = threading.RLock()
        super(MyThread, self).__init__()
        self.func = func
        self.args = args

    def run(self):
        # 锁上
        self.lock.acquire()  
        self.result = self.func(*self.args)
        # 解锁
        self.lock.release()

    def get_result(self):
        try:
            return self.result
        except Exception:
            return None





## 定义访问接口
interfaceurl = "http://10.8.0.37:5000/gttx/objectrecognition"
# C:/Users/15256/Desktop/nowtime/yolov_smoke_v1.0/yolov5/smokingdata/images/train/000001.jpg
## 将要传入的数据设置为json格式
# http://pili-live-hdl.miaobolive.com/live/dfbe2bcc0acd956bda5c9a3d133e5c18.flv
# information = { 'path' : r'C:\Users\15256\Desktop\nowtime\吸烟视频\2.mp4',  
#                 'savePath' :'targetimages'} 
# information = { 'path' : 'http://pili-live-hdl.miaobolive.com/live/76db77b91f9248d3e21eef0f1e815f37.flv',  
#                 'savePath' :'./target/test'} 
# information = json.dumps(information)
import random
## 数据打包传输
for i in range(200):
    information = { 'path' : 'http://pili-live-hdl.miaobolive.com/live/6e8d175660edc74ea70f54abbd598c8a.flv',  
                'savePath' :'./target/test/%s'%(str(random.randint(1,10000)))} 
    information = json.dumps(information)
    # _Data = information
    MyThread(requests.post,args=(interfaceurl,information,)).start()
    print(i)
    # response = requests.post(interfaceurl, data=information)
    # response = requests.post(interfaceurl, data=information)
    # print(response)
    # print(response.json())
# requests.post(interfaceurl, data=information)