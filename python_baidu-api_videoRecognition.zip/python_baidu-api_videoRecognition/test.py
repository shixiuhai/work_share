import os
import time
import random
# file_path = save_path + '/' + now+ '.wav'
now = time.strftime("%Y-%m-%d-%H_%M_%S",time.localtime(time.time()))
# 图片存储路径
file_path = 'target' + '/' + 'test' + '/' + now  + str(random.randint(1,10000))+ '.jpg'
for i in range(10):
    file_path = 'target' + '/' + 'test' + '/' + now  + str(random.randint(1,10000))+ '.jpg'
    # time.sleep(1)
    save_cmd = "C:/Users/15256/Downloads/2021-10-26-00-34-45-www.gyan.dev-ffmpeg-4.4.1-full_build-shared/ffmpeg-4.4.1-full_build-shared/bin/ffmpeg.exe -i http://pili-live-hdl.miaobolive.com/live/6e8d175660edc74ea70f54abbd598c8a.flv -r 1 -t 0.1 -f image2   %s"%file_path
    os.system(save_cmd)