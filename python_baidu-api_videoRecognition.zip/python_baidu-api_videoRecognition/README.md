### 1. 这个项目是调用百度api对视频链接进行截图识别返回结果

### 2. accetoken.py是获取请求accetoken的函数

### 3. main.py 是项目的主代码

### 4. post_test.py 是提交测试例子

### 5. requirements.txt是虚拟环境需要的依赖包
### 6. test.py是项目测试某些python写法的文件

