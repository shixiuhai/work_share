from os import access
import requests
import base64
from accetoken import *
import cv2
import time
import os
from PIL import Image
from io import BytesIO
from flask import Flask, request
'''
图像审核接口,功能调用百度api对视频流进行截图处理
'''
def process_video_to_images(path,save_path):
    # 文件夹路径不存在去创建
    if not os.path.exists(save_path):
        # print('已经创建路径'+ save_path)
        os.makedirs(save_path)
    now = time.strftime("%Y-%m-%d-%H_%M_%S",time.localtime(time.time()))
    # 图片存储路径
    file_path = save_path + '/' + now + '.jpg'
    # print(path,file_path)
    save_cmd = "C:/Users/15256/Downloads/2021-10-26-00-34-45-www.gyan.dev-ffmpeg-4.4.1-full_build-shared/ffmpeg-4.4.1-full_build-shared/bin/ffmpeg.exe -loglevel quiet -i %s -r 1 -t 0.1 -f image2  %s"%(path,file_path)
    try:
        # 执行保存
        os.system(save_cmd)
        f = open('%s'%(file_path), 'rb')
        img = base64.b64encode(f.read())
        # !!!!!!!!!关闭文件很重要
        f.close()
        return picture_save_alert(img,save_path,file_path)
    except:
        print('视频打开失败')
        return json.dumps({'conclusionType':6,'conclusion': '视频打开失败'},ensure_ascii=False)

def picture_save_alert(img,save_path,file_path):
    # print('hello word')
    request_url = "https://aip.baidubce.com/rest/2.0/solution/v1/img_censor/v2/user_defined"
    # 识别
    params = {"image":img}
    access_token = '%s'%get_accesstoken()
    # access_token = '24.a6252d0fc87a8d462ccb4cb9f4a7e390.2592000.1640328040.282335-2521363'
    request_url = request_url + "?access_token=" + access_token
    headers = {'content-type': 'application/x-www-form-urlencoded'}
    response = requests.post(request_url, data=params, headers=headers)
    # print('+++++++++')
    # print(response.json())
    # print('+++++++++')
    try:
        # 请求成功
        if response:
            print('合规')
            if response.json()['conclusionType'] in [1,3,4]:
                # print(type(response.json()['conclusionType']))
                # print(id,companyId)
                # 图片命名规则
                # cv2.imwrite("%s/%s.jpg"%(save_path,now),frame)
                # print('图片合规的')
                result = response.json()
                result = dict(result)
                # 移除图片
                os.remove(file_path)
                # 返回成功的数据
                return json.dumps(result,ensure_ascii=False)
            
            # 不合规
            elif response.json()['conclusionType'] == 2:
                print('不合规')
                # 不合规返回图片路径
                # 数据返回结果
                result = response.json()
                result = dict(result)
                # 更新数据
                result.update({
                    'imagePath':file_path
                })
                
                # 返回成功的数据
                return json.dumps(result,ensure_ascii=False)
                # return str(result)
            else:
                print('百度接口调用失败')
                return json.dumps({'conclusionType':5,'conclusion': '百度接口调用失败'},ensure_ascii=False)
    except:
        print('百度接口调用失败')
        return json.dumps({'conclusionType':5,'conclusion': '百度接口调用失败'},ensure_ascii=False)


"""flask接口"""
server = Flask(__name__)
@server.route('/gttx/objectrecognition', methods=['post'])
def objectrecognition():
    """
    通过接口解析json数据
    """
    if not request.data:
        # 返回没有数据
        print('百度接口调用失败')
        return json.dumps({'conclusionType':5,'conclusion': '百度接口调用失败'},ensure_ascii=False)
        # return json.dumps("{'message': 'None'}",ensure_ascii=False)
    # 以utf-8编码接收json数据
    information = request.data
    # 解析json数据为字典格式
    information = json.loads(information)
    # try:
    path = information['path']
    save_path = information['savePath']
    # 调用函数
    result = process_video_to_images(path,save_path)
    return result

if __name__ == '__main__':
    """
    启动flask服务
    """
    # 指定端口,host,0.0.0.0代表不管几个网卡，任何ip都可访问
    # server.run(debug=True, threaded=True,port=5000, host='127.0.0.1') # 多线程指定
    # 多进程指定，各个进程之间不冲突
    server.run(debug=False, processes=True,port=5000, host='0.0.0.0')
